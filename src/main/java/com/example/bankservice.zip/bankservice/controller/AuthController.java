package com.example.bankservice.controller;

import com.example.bankservice.dto.AuthenticateDto;
import com.example.bankservice.dto.LoginRequestDto;
import com.example.bankservice.dto.RegisterRequestDto;
import com.example.bankservice.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;




@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService){
        this.authService = authService;
    }
    @PostMapping("/register")
    public ResponseEntity<AuthenticateDto> register(@Valid @RequestBody RegisterRequestDto registerRequestDto){
        AuthenticateDto authenticateDto = authService.register(registerRequestDto);
        return ResponseEntity.ok(authenticateDto);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthenticateDto> login(@Valid @RequestBody LoginRequestDto loginRequestDto){
        AuthenticateDto authenticateDto = authService.login(loginRequestDto);
        return  ResponseEntity.ok(authenticateDto);
    }


}
